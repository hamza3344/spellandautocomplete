﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spellandautocomplete
{
    public partial class Form1 : Form
    {
        System.Windows.Controls.TextBox textBox;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox = new System.Windows.Controls.TextBox();
            textBox.TextWrapping = System.Windows.TextWrapping.Wrap;
            textBox.AcceptsReturn = true;
            textBox.FontSize = 16;
            textBox.FontFamily = new System.Windows.Media.FontFamily("Times New Roman");
            textBox.SpellCheck.IsEnabled = true;
            elementHost1.Child = textBox;
            textBox1.AutoCompleteMode = AutoCompleteMode.Suggest;
            textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection col = new AutoCompleteStringCollection();
            col.Add("I upload videos of difficult coding task");
            col.Add("PLease subcribe my channel");
            col.Add("Like and Share the video");
            textBox1.AutoCompleteCustomSource = col;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBox.Text);
        }
    }
}
